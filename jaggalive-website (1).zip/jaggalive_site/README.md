# Jagga Live — GitHub Pages

A responsive single-page website for the Kick channel `jaggajd`.

## Preview locally
Open `index.html` in a browser.

## Publish at jaggalive.github.io
1. Create a GitHub repository named exactly `jaggalive.github.io` under the GitHub account `jaggalive`.
2. Upload `index.html` and the `assets` folder (keep the folder structure unchanged).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish. The site should be available at `https://jaggalive.github.io/`.

The Kick player embeds `https://player.kick.com/jaggajd`; the channel buttons link to `https://kick.com/jaggajd`.

## Customization
- Replace `assets/jagga-portrait.png` to change the portrait/logo.
- Update the channel username in the Kick player and channel links if it changes.
- Discord, YouTube, and Instagram links were not added because invite/profile URLs were not supplied.
